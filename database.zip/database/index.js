const express = require("express")
const mongoose = require("mongoose")

app = express()

mongoose.connect("mongodb+srv://admin:odinho@health.ild7aah.mongodb.net/")
    .then(() => {
        console.log("connected")
        next()
    })
    .catch((e) => {
        console.log(e)
        res.send(202)
    })

app.get("/", (req, res) => {
    res.send("ok")
})

app.listen("3000", () => {
    console.log("up")
})

