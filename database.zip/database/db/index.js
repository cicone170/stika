const mongoose = require("mongoose")




const medicamentSchema = new mongoose.Schema({
    nomMedic: {
        type: String,
    },
    dose: {
        type: String,
    },
    duree: {
        type: String,
    },
    statut: {
        type: String,
        enum: ["traitement medicamental", "traitement non medicamental"]
    },
})

const medicamentModel = mongoose.model("Medicament", medicamentSchema)


const vaccinSchema = new mongoose.Schema({
    nom: {
        type: String,
    },
    dateVaccination: {
        type: Date,
    },
})

const vaccinModel = mongoose.model("Vaccin", vaccinSchema)


const interventionChirurgicaleSchema = new mongoose.Schema({
    nomInter: {
        type: String,
    },
    dateInter: {
        type: Date,
    },
    rapport: {
        type: File,
    },
})

const interventionChirurgicaleModel = mongoose.model("Intervention", interventionChirurgicale)


const userSchema = new mongoose.Schema({
    nom: {
        type: String,
        required: [true, "Username connot be blank"],
    },
    prenom: {
        type: String,
        required: true,
    },
    nin: {
        type: Number,
        required: true,
    },
    numTel: {
        type: Number,
        required: true,
    },
    dateNaissance: {
        type: Date,
        required: true,
    },
    sexe: {
        type: String,
        enum: ["M", "F"],
    },
    email: {
        type: String,
        required: true,
    },
    mdp: {
        type: String,
        required: true,
    },
    dossierMed: {
        donGen: {
            poids: {
                type: Number,
            },
            taille: {
                type: Number,
            },
            imc: {
                type: Number,
            },
            pressArt: {
                type: Number,
            },
            regimeAlim: {
                type: String,
            },
            consomAlcool: {
                type: String,
            },
            tabagisme: {
                type: String,
            },
            activitePhys: {
                type: String,
            },
            nivStresse: {
                type: String,
            },
        },
        hisDiag: {
            Docteur: {
                type: [mongoose.ObjectId],
            },
        },
        diag: {
            type: String,
        },
    },
    examMedicaux: {
        analyseLabo: {
            type: File,
        },
        radios: {
            type: File,
        },
        autresExam: {
            type: File,
        },
    },
    medicaments: {
        type: [medicamentSchema]
    },
    antecedentsMedic: {
        maladiesChroniques: {
            type: [String],
        },
        antecedFamil: {
            type: [String],
        },
        allergies: {
            type: [String],
        },
        vaccinations: {
            type: [vaccinSchema],
        },
    },
    interChirirgicale: {
        type: [interventionChirurgicaleSchema],
    },
    docAdministratifs: {
        consentement: {
            type: [File],
        },
        directive: {
            type: [File],
        },
        assurance: {
            type: [File],
        },
    },
},
)